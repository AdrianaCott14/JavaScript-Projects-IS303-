// this program will take a number entered from an input box and roll (genereating random numbers) of series of 5 dice until that number is rolled. The program will count how many rolls it took to get the desired number and store those numbers in an array. Afterwhich, the roll function will call another function that takes that array as a parmater and will form an output for that data.

function rollTheDie() {
    //get input for number to get
    let numToRoll = document.getElementById("dieInput").value;
    //error check
    if (numToRoll < 1 || numToRoll > 6) {
            alert("Please enter a number between 1 and 6");
            document.getElementById("dieInput").value = "";
            document.getElementById("dieInput").focus();
            numToRoll = document.getElementById("dieInput").value; 
    }
    else {
        //roll each die till desired number is got
        let arrDice = [1, 2, 3, 4, 5];
        let arrDieRolls = [];
        //to roll each die
        for (let iCount = 0; iCount < arrDice.length; iCount++) {
            let iRoll = 0;
            let iRollCounter = 0;
            //rolling to get the number
            while (iRoll != numToRoll) {
                iRoll = Math.floor(Math.random() * 7);
                iRollCounter += 1;
            }
            arrDieRolls.push(iRollCounter);
        }
        displayResults(arrDieRolls);
        //display the images 
        document.getElementById("image").innerHTML = "<img src='dice" + numToRoll + "Use.jpg' alt='dice'>" + "<img src='dice" + numToRoll + "Use.jpg' alt='dice'>" + "<img src='dice" + numToRoll + "Use.jpg' alt='six dice'>" + "<img src='dice" + numToRoll + "Use.jpg' alt='dice'>" + "<img src='dice" + numToRoll + "Use.jpg' alt='dice'>";
    
        return arrDieRolls;
    }
}

function displayResults(arrTheRolls) {
    let iTotalRolls = 0;
    //get grand total
    for (let iCount = 0; iCount < arrTheRolls.length; iCount++) {
        iTotalRolls += arrTheRolls[iCount];
    }
    console.log(iTotalRolls);
    let diceRollOutput = "";

    for (iCount = 0; iCount < arrTheRolls.length; iCount++) {
        diceRollOutput += "Dice " + (iCount + 1) + " rolls = " + arrTheRolls[iCount] + "<br>";
    }
    document.getElementById("diceOutput").innerHTML = diceRollOutput;
    document.getElementById("grandTotal").innerHTML = "Total number of rolls: " + iTotalRolls;
}



